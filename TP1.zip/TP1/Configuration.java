import javax.swing.*;

public class Configuration {
    private final String description = "";
    private final int MAX_COMPOSANTS = 20;
    private int prixMax;
    private Composant composants[] = new Composant[MAX_COMPOSANTS];

    public Configuration( String description, int prixMax, Composant[] composants){
        this.prixMax = prixMax;
        this.composants = composants;
    }
    //getters et setters
    
    
}
